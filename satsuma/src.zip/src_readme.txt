FOR WINDOWS USERS:

To generate Doxygen HTML documentation, you will need to install Perl (http://strawberryperl.com/ or another Perl variant). Otherwise Doxygen will not work and you will not be able to generate HTML documentation for Satsuma.
